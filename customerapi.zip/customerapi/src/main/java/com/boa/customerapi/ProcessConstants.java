package com.boa.customerapi;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "customerapi"; // BPMN Process ID

}
